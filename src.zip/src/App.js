// src/App.js
import React, { useEffect, useState } from "react";
import "./App.css";
import AboutSection from "./components/AboutSection";
import SkillSection from "./components/SkillSection";
import ScrollFloatingButtons from "./components/ScrollFloatingButtons";
import Footer from "./components/Footer";
import Hero from "./components/Hero";

function App() {
  const [showHeader, setShowHeader] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > lastScrollY) {
        setShowHeader(false);
      } else {
        setShowHeader(true);
      }
      setLastScrollY(window.scrollY);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (id) => {
    document.getElementById(id).scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="App">
      {/* 고정 헤더 */}
      <header className={`header ${showHeader ? "visible" : "hidden"}`}>
        <nav>
          <button onClick={() => scrollToSection("about")}>자기소개</button>
          <button onClick={() => scrollToSection("skills")}>스킬 & 툴</button>
        </nav>
      </header>

   {/* Hero 섹션 */}
      <section className="hero">
        <Hero />
      </section>

      {/* 자기소개 */}
      <section id="about" >
        <AboutSection />
      </section>

      {/* 스킬 */}
      <section id="skills" >
      <SkillSection />
      </section>
    <ScrollFloatingButtons />
  <Footer />
    </div>
  );
  <section id="about" className="section">
  <AboutSection />
</section>

}

export default App;
