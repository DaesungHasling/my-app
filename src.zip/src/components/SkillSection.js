import React, { useState, useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

import {
  FaReact, FaHtml5, FaCss3Alt, FaJs,
  FaPython, FaGitAlt, FaDatabase, FaCode
} from 'react-icons/fa';

import './SkillSection.css';

const skills = [
  { name: 'React', icon: <FaReact />, color: '#61DBFB', description: '프론트엔드 라이브러리', category: 'Frontend' },
  { name: 'HTML5', icon: <FaHtml5 />, color: '#E44D26', description: '웹 구조 언어', category: 'Frontend' },
  { name: 'CSS3', icon: <FaCss3Alt />, color: '#264de4', description: '웹 스타일 언어', category: 'Frontend' },
  { name: 'JavaScript', icon: <FaJs />, color: '#F7DF1E', description: '웹 스크립트 언어', category: 'Frontend' },
  { name: 'Python', icon: <FaPython />, color: '#3776AB', description: '백엔드 및 AI', category: 'Backend' },
  { name: 'Java', icon: <FaCode />, color: '#007396', description: '백엔드 언어', category: 'Backend' },
  { name: 'C', icon: <FaCode />, color: '#A8B9CC', description: '시스템 언어', category: 'Backend' },
  { name: 'R', icon: <FaCode />, color: '#276DC3', description: '통계 분석 언어', category: 'Data Analysis' },
  { name: 'Excel', icon: <FaCode />, color: '#217346', description: '데이터 분석 도구', category: 'Data Analysis' },
  { name: 'MySQL', icon: <FaDatabase />, color: '#00618A', description: '데이터베이스', category: 'Backend' },
  { name: 'Git', icon: <FaGitAlt />, color: '#F05032', description: '버전 관리 도구', category: 'Tools' },
];

const categories = ['All', 'Frontend', 'Backend', 'Data Analysis', 'Tools'];

const SkillSection = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  const filteredSkills =
    selectedCategory === 'All'
      ? skills
      : skills.filter(skill => skill.category === selectedCategory);

  return (
    <section className="brand-skill-section" id="skills">
      <h2>Skills & Tools</h2>

      <div className="category-buttons">
        {categories.map(category => {
          const className = `${category.toLowerCase().replace(/\s+/g, '')} ${selectedCategory === category ? 'active' : ''}`;
          return (
            <button
              key={category}
              className={className}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </button>
          );
        })}
      </div>

      <div className="brand-skill-grid">
        {filteredSkills.map(skill => (
          <div
            key={skill.name}
            className={`brand-skill-card ${skill.category.toLowerCase().replace(/\s+/g, '')}`}
            data-aos="fade-up"
          >
            <div className="card-inner">
              <div className="card-front">
                <div className="icon" style={{ color: skill.color }}>
                  {skill.icon}
                </div>
                <h3>{skill.name}</h3>
              </div>
              <div className="card-back">
                <p>{skill.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default SkillSection;
