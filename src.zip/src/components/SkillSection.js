import React, { useState } from "react";
import "./SkillSection.css";

const skills = {
  "💻 프론트엔드": [
    { name: "HTML", level: 1, color: "#f16529", description: "웹 페이지 구조 작성 가능" },
    { name: "CSS", level: 1, color: "#2965f1", description: "스타일 구성 가능" },
    { name: "JavaScript", level: 1, color: "#f0db4f", description: "기초 문법 숙지" },
    { name: "React", level: 1, color: "#61dafb", description: "컴포넌트 UI 기초 이해" },
  ],
  "🛠️ 백엔드": [
    { name: "C언어", level: 1, color: "#555", description: "기초 입출력 가능" },
    { name: "Python", level: 1, color: "#3572A5", description: "문법과 변수 이해" },
    { name: "Java", level: 1, color: "#b07219", description: "OOP 기초 학습 중" },
  ],
  "📊 데이터 분석": [
    { name: "R", level: 1, color: "#276dc3", description: "통계용 기본 함수 가능" },
    { name: "엑셀", level: 1, color: "#217346", description: "기본 함수 사용 가능" },
  ],
  "🧰 협업 툴": [
    { name: "GitHub", level: 1, color: "#333", description: "저장소 생성 및 커밋 가능" },
  ],
};

const SkillSection = () => {
  const [openCategories, setOpenCategories] = useState([]);

  const toggleCategory = (category) => {
    if (openCategories.includes(category)) {
      setOpenCategories(openCategories.filter((c) => c !== category));
    } else {
      setOpenCategories([...openCategories, category]);
    }
  };

  return (
    <section className="skill-section">
      <h2>Skills & Tools</h2>
      {Object.entries(skills).map(([category, items]) => (
        <div key={category} className="skill-category">
          <button className="skill-toggle" onClick={() => toggleCategory(category)}>
            {openCategories.includes(category) ? "▼" : "+"} {category}
          </button>
          {openCategories.includes(category) && (
            <div className="skill-grid">
              {items.map((skill, idx) => (
                <div className="skill-card" key={idx}>
                  <div className="skill-header">
                    <span className="skill-dot" style={{ backgroundColor: skill.color }}></span>
                    <span className="skill-name">{skill.name}</span>
                  </div>
                  <div className="skill-bar-segments">
                    {[1, 2, 3, 4, 5].map((step) => (
                      <div
                        key={step}
                        className={`skill-segment ${
                          skill.level >= step ? "active" : ""
                        }`}
                      ></div>
                    ))}
                  </div>
                  <p className="skill-description">{skill.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </section>
  );
};

export default SkillSection;
