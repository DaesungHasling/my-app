// src/components/AboutSection.js
import React, { useState } from "react";
import "./AboutSection.css";

const introData = [
  {
    title: "성장과정",
    content: "저는 어릴 적부터 컴퓨터에 흥미를 느껴 관련 분야에 대한 꿈을 키웠습니다...",
  },
  {
    title: "성격의 장단점",
    content: "꼼꼼하고 책임감이 강한 성격입니다. 때때로 완벽주의 성향이 단점이 될 수 있습니다.",
  },
  {
    title: "자격증",
    content: "정보처리기사, 컴퓨터활용능력 1급, 웹디자인기능사 등 다양한 자격증을 취득하였습니다.",
  },
  {
    title: "군대",
    content: "2018년부터 2020년까지 육군 병장으로 만기 전역하였습니다.",
  },
  {
    title: "경력",
    content: "대학 프로젝트 및 인턴십을 통해 실제 프론트엔드 개발 경험을 쌓았습니다.",
  },
  {
    title: "학력",
    content: "○○대학교 컴퓨터공학과 졸업 (2019~2023)",
  },
];

function AboutSection() {
  const [index, setIndex] = useState(0);

  const handlePrev = () => setIndex((prev) => (prev === 0 ? introData.length - 1 : prev - 1));
  const handleNext = () => setIndex((prev) => (prev === introData.length - 1 ? 0 : prev + 1));

  return (
    <section id="about" className="about-section">
      <div className="card">
        <h2>{introData[index].title}</h2>
        <p>{introData[index].content}</p>
        <div className="navigation">
          <button onClick={handlePrev}>←</button>
          <div className="indicators">
            {introData.map((_, i) => (
              <span key={i} className={i === index ? "dot active" : "dot"}></span>
            ))}
          </div>
          <button onClick={handleNext}>→</button>
        </div>
      </div>
    </section>
  );
}

export default AboutSection;

