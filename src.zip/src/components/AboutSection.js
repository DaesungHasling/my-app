// src/components/AboutSection.js
import React from 'react';
import './AboutSection.css'; // 선택사항: 스타일 분리 시 사용
import profileImage from '../images/Daesung1.jpg'; // 새 이미지 경로

const AboutSection = () => {
  return (
    <section id="about" className="about-section">
      <div className="about-container">
        {/* 왼쪽: 텍스트 */}
        <div className="about-text">
          <h2>About Me</h2>
          <p>
            저는 끊임없이 도전하며 변화에 적응하는 오뚝이 같은 개발자 지망생입니다. 
            학창시절 항공정비사를 꿈꾸며 세 개의 기능사와 산업기사 자격증을 취득하였고, 
            군 복무 중에는 CH-47 대형기동헬기 정비병으로 복무하며 항공기의 안전과 관련된 실무 경험과 책임감을 배울 수 있었습니다.
          </p>
          <p>
            이후 지상 조업과 중정비 현장에서 근무하며 하드웨어에 대한 이해를 쌓았고, 
            점차 소프트웨어 개발에 흥미를 느끼게 되어 항공정비사를 그만두고 새로운 길에 도전하게 되었습니다.
          </p>
          <p>
            체력과 학습 습관을 다지기 위해 컴퓨터 학원과 운동을 병행하며 스스로를 관리했고, 
            더 깊이 공부하고자 AI소프트웨어학과에 진학하여 본격적으로 개발 공부를 시작했습니다.
          </p>
          <p>
            입학 후에는 과대표를 맡고 직접 ‘코드 크루’ 동아리를 만들어 자격증 취득 학습을 주도하였으며, 
            그 결과 총 9명의 필기 합격자 배출과 함께 정보처리산업기사, 사무자동화산업기사 자격증을 취득할 수 있었습니다. 
            동아리 활동과 조별 프로젝트를 통해 프로그래밍 역량과 협업 능력, 그리고 꾸준한 도전 정신을 키워가고 있습니다.
          </p>
        </div>

        {/* 오른쪽: 이미지 */}
        <div className="about-image">
          <img src={profileImage} alt="Profile" />
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
