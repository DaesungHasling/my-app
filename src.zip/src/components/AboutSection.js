// src/components/AboutSection.js
import React from 'react';
import './AboutSection.css'; // 선택사항: 스타일 분리 시 사용
import profileImage from '../images/Daesung1.jpg'; // 새 이미지 경로

const AboutSection = () => {
  return (
    <section id="about" className="about-section">
      <div className="about-container">
        {/* 왼쪽: 텍스트 */}
        <div className="about-text">
          <h2>About Me</h2>
          <p>
            안녕하세요. 끊임없이 도전하고 변화에 유연하게 적응하며 다시 일어서는 오뚝이 같은 개발자 지망생입니다.
          </p>
          <p>
            저는 19살부터 25살까지 항공정비를 전공하며 기계와 시스템에 대한 기초 역량을 쌓았습니다. 하지만 소프트웨어 개발에 점점 더 흥미를 느끼게 되어 새로운 길에 도전했습니다.
          </p>
          <p>
            ICT폴리텍대학교 AI소프트웨어학과에 진학하여 개발자로서의 첫걸음을 내딛었고, 과대표로서 학과 분위기를 이끌며 ‘코드 크루’라는 동아리를 자발적으로 만들고 자격증 학습을 주도했습니다.
          </p>
          <p>
            지금까지 총 9명의 필기 합격자를 배출했으며, 정보처리기능사, 산업기사, 사무자동화산업기사 필기를 취득하였습니다.
          </p>
        </div>

        {/* 오른쪽: 이미지 */}
        <div className="about-image">
          <img src={profileImage} alt="Profile" />
        </div>
        
      </div>
    </section>
    
  );
};

export default AboutSection;
