import React from "react";
import { FaInstagram } from "react-icons/fa";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-left">
          <a
            href="https://www.instagram.com/daesung.ch_99/"
            target="_blank"
            rel="noreferrer"
            className="footer-icon"
          >
            <FaInstagram size={20} />
          </a>
        </div>
        <div className="footer-center">
          <span className="footer-name">최대성</span>
          <span className="footer-divider">|</span>
          <a href="mailto:eotjd990809@naver.com" className="footer-email">
            eotjd990809@naver.com
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
