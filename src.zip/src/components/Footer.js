// src/components/Footer.js
import React from "react";
import { FaInstagram } from "react-icons/fa";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-left">
          <a
            href="https://instagram.com/yourprofile"
            target="_blank"
            rel="noreferrer"
            className="footer-icon"
          >
            <FaInstagram size={20} />
          </a>
        </div>
        <div className="footer-center">
          <span className="footer-name">홍길동</span>
          <span className="footer-divider">|</span>
          <a href="mailto:your@email.com" className="footer-email">
            your@email.com
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
