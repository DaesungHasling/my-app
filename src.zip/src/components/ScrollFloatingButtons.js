// src/components/ScrollFloatingButtons.js
import React, { useEffect, useState } from "react";
import "./ScrollFloatingButtons.css";
import { FaGithub, FaEnvelope, FaArrowUp } from "react-icons/fa";

const ScrollFloatingButtons = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    visible && (
      <div className="floating-buttons">
        <a
          href="https://github.com/DaesungHasling/my-app" // ← 본인의 깃허브 링크로 변경
          target="_blank"
          rel="noreferrer"
          title="GitHub"
        >
          <FaGithub />
        </a>
        <a href="mailto:your@email.com" title="Email">
          <FaEnvelope />
        </a>
        <button onClick={scrollToTop} title="맨 위로">
          <FaArrowUp />
        </button>
      </div>
    )
  );
};

export default ScrollFloatingButtons;
